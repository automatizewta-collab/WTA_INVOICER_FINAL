import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { z } from "zod";

const itemSchema = z.object({
  code: z.string().min(1, "Code is required"),
  namePt: z.string().min(1, "Name (PT) is required"),
  nameEn: z.string().min(1, "Name (EN) is required"),
  nameEs: z.string().optional().nullable(),
  unitValueUsd: z.number().min(0),
  grossWeight: z.number().min(0),
  netWeight: z.number().min(0),
  htsusCode: z.string().optional().nullable(),
  endUse: z.string().optional().nullable(),
  endUseEs: z.string().optional().nullable(),
  sterileAtImport: z.string().default("NO"),
});

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const search = searchParams.get("search") || "";

    const items = await db.item.findMany({
      where: search
        ? {
            OR: [
              { code: { contains: search } },
              { namePt: { contains: search } },
              { nameEn: { contains: search } },
            ],
          }
        : undefined,
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json(items);
  } catch (error) {
    console.error("GET /api/items error:", error);
    return NextResponse.json({ error: "Failed to fetch items" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = itemSchema.parse(body);
    const item = await db.item.create({ data });
    return NextResponse.json(item, { status: 201 });
  } catch (error: unknown) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.issues[0].message }, { status: 400 });
    }
    console.error("POST /api/items error:", error);
    return NextResponse.json({ error: "Failed to create item" }, { status: 500 });
  }
}