Documentação do Sistema de Documentos Comerciais

## Visão Geral

Sistema de geração e gestão de documentos comerciais de exportação (Proforma, Invoice, Packing List) com suporte a inglês e espanhol.

---

## Rotas da Aplicação

| Rota | Página | Descrição |
|------|--------|-----------|
| `/` | `Dashboard` | Tela inicial com resumo de documentos recentes |
| `/Documents` | `Documents` | Lista todos os documentos, filtros por tipo, geração de PDF |
| `/NewDocument` | `NewDocument` | Formulário de criação de novo documento |
| `/EditDocument?id={id}` | `EditDocument` | Edição de documento existente, recebe `id` via query param |
| `/Items` | `Items` | Cadastro e gerenciamento de itens do catálogo |
| `/Companies` | `Companies` | Cadastro de empresas remetentes e destinatárias |
| `/Settings` | `Settings` | Configurações gerais da aplicação |

---

## Entidades (Banco de Dados)

### `Document`
Representa um documento comercial.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `id` | string | ID único (gerado automaticamente) |
| `document_type` | enum: `proforma`, `invoice`, `packing_list` | Tipo do documento |
| `status` | enum: `draft`, `issued` | Status do documento |
| `language` | enum: `en`, `es` | Idioma do documento |
| `number` | string | Número do documento |
| `date` | date | Data de emissão |
| `sender_id` | string | ID da empresa remetente |
| `recipient_id` | string | ID da empresa destinatária |
| `items` | array de objetos | Lista de itens (ver estrutura abaixo) |
| `dollar_exchange_rate` | number | Cotação do dólar (referência BRL) |
| `currency` | enum: `USD`, `EUR` | Moeda do documento |
| `htsus_column_title` | string | Título da coluna de classificação tarifária |
| `show_sterile_column` | boolean | Exibe coluna "Sterile at Import" |
| `origin_proforma_id` | string | ID da Proforma que originou este documento |
| `shipment_details` | objeto | Detalhes de embarque (ver abaixo) |
| `financial_details` | objeto | Detalhes financeiros (ver abaixo) |
| `notes` | array de strings | Notas do documento |
| `pdf_url` | string | URL do PDF gerado |

**Estrutura de item dentro de `items`:**
```json
{
  "item_id": "string",
  "quantity": "number",
  "unit_price": "number",
  "discount": "number",
  "line_number": "number",
  "gross_weight": "number",
  "net_weight": "number",
  "htsus_code": "string",
  "sterile_at_import": "YES | NO"
}
```

**Estrutura de `shipment_details`:**
```json
{
  "carrier": "string",
  "incoterms": "string",
  "origin_port": "string",
  "destination_port": "string",
  "shipment_date": "date",
  "awb": "string",
  "boxes": [{ "quantity": "number", "type": "string", "dimensions": "string" }],
  "gross_weight": "number",
  "net_weight": "number"
}
```

**Estrutura de `financial_details`:**
```json
{
  "discount": "number",
  "shipping_cost": "number",
  "insurance": "number",
  "bank_fees": "number",
  "total_value": "number"
}
```

---

### `Item`
Itens do catálogo de produtos.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `id` | string | ID único |
| `code` | string | Código do item |
| `name_pt` | string | Nome em português |
| `name_en` | string | Nome em inglês |
| `name_es` | string | Nome em espanhol |
| `unit_value_usd` | number | Valor unitário em USD |
| `gross_weight` | number | Peso bruto (kg) |
| `net_weight` | number | Peso líquido (kg) |
| `htsus_code` | string | Código tarifário (formato 0000.00.0000) |
| `end_use` | string | Finalidade de uso (inglês) |
| `end_use_es` | string | Finalidade de uso (espanhol) |
| `sterile_at_import` | string (`YES`/`NO`) | Se é estéril na importação |

---

### `Company`
Empresas remetentes e destinatárias.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `id` | string | ID único |
| `name` | string | Nome da empresa |
| `type` | enum: `sender`, `recipient` | Tipo da empresa |
| `contact_name` | string | Nome do contato |
| `address` | string | Endereço |
| `city` | string | Cidade |
| `postal_code` | string | Código postal |
| `state` | string | Estado/Província |
| `country` | string | País |
| `email` | string | E-mail |
| `phone` | string | Telefone |
| `cnpj` | string | CNPJ (empresas brasileiras) |
| `state_registration` | string | Inscrição Estadual |
| `is_default` | boolean | Se é a empresa padrão do tipo |
| `logo_url` | string | URL do logotipo |
| `bank_details` | string | Dados bancários (SWIFT, endereço banco) |
| `mid_code` | string | Manufacturer Identification Code |

---

## Fluxo de Criação de Documentos

### Criando uma Proforma (`NewDocument`)
1. Usuário preenche o formulário com tipo = **Proforma**
2. Ao emitir, o sistema cria **3 documentos automaticamente**:
   - `Proforma` → número: `{number}`
   - `Invoice` → número: `{number}-INV`
   - `Packing List` → número: `{number}-PL`
3. Todos compartilham os mesmos itens, datas e dados de embarque
4. O Packing List tem `financial_details` zerados

### Criando uma Invoice (`NewDocument`)
1. Usuário preenche com tipo = **Invoice**
2. Ao emitir, cria **2 documentos**:
   - `Invoice` → número: `{number}`
   - `Packing List` → número: `{number}-PL`

### Criando apenas Packing List (`NewDocument`)
- Cria somente 1 documento do tipo `packing_list`

---

## Fluxo de Edição de Documentos

### Editando uma Proforma (`EditDocument`)
1. Ao salvar, atualiza a Proforma pelo `documentId`
2. Busca Invoice filha pelo número **original** + `-INV` (antes de qualquer mudança de número)
3. Busca Packing List filha pelo número **original** + `-PL`
4. Se encontrados → atualiza; se não → cria novos

### Editando uma Invoice (`EditDocument`)
1. Ao salvar, atualiza a Invoice pelo `documentId`
2. Busca Packing List pelo número novo + `-PL`
3. Se encontrado → sincroniza; se não → apenas avisa

### Sincronização de Packing List com Invoice
- Botão disponível ao editar um Packing List
- Remove sufixo `-PL` do número atual para localizar a Invoice correspondente
- Copia itens, datas, dados de embarque e notas da Invoice para o Packing List

---

## Geração de PDF

O PDF é gerado no frontend via HTML puro, sem biblioteca externa:

1. `handleGeneratePDF` em `Documents.jsx` é acionado
2. Busca empresa remetente e destinatária via `fetchCompany`
3. Busca itens atualizados do catálogo via `fetchDocumentItems`
   - `end_use` e `end_use_es` são **sempre lidos do catálogo** (não do documento salvo)
4. `generatePrintableHTML` monta o HTML completo com estilos inline
5. Abre uma nova janela do browser com o HTML
6. Usuário imprime com `Ctrl+P` e salva como PDF

**Seleção de idioma no PDF:**
- `document.language === "es"` → usa `name_es`, `end_use_es` e textos em espanhol
- caso contrário → usa `name_en`, `end_use` e textos em inglês

---

## SDK Base44 Utilizado

```js
import { base44 } from '@/api/base44Client';

// Entidades
base44.entities.Document.list()
base44.entities.Document.filter({ number: "ABC-INV" })
base44.entities.Document.create({ ... })
base44.entities.Document.update(id, { ... })
base44.entities.Document.delete(id)

base44.entities.Item.list()
base44.entities.Company.list()

// Autenticação
base44.auth.me()
base44.auth.logout()

// Integrações
base44.integrations.Core.InvokeLLM({ prompt: "..." })
base44.integrations.Core.UploadFile({ file })
base44.integrations.Core.SendEmail({ to, subject, body })
```

---

## Componentes Principais

| Componente | Localização | Descrição |
|------------|-------------|-----------|
| `DocumentItemsTable` | `components/documents/` | Tabela de seleção e edição de itens do documento |
| `ShipmentDetailsForm` | `components/documents/` | Formulário de detalhes de embarque e caixas |
| `NotesForm` | `components/documents/` | Gerenciamento dinâmico de notas |
| `LanguageToggle` | `components/documents/` | Alternância EN/ES do documento |
| `NewItemForm` | `components/items/` | Formulário de criação de item no catálogo |
| `EditItemForm` | `components/items/` | Formulário de edição de item no catálogo |
| `SenderForm` | `components/companies/` | Formulário de empresa remetente |
| `RecipientForm` | `components/companies/` | Formulário de empresa destinatária |
| `CompanyCard` | `components/companies/` | Card de exibição de empresa |
| `RecentDocuments` | `components/dashboard/` | Lista de documentos recentes no Dashboard |
| `Layout` | `layout.jsx` | Sidebar + navegação principal |

---

## Convenção de Numeração de Documentos

| Tipo | Formato |
|------|---------|
| Proforma | `{AAMMXXXXXX}` (ex: `2605123456`) |
| Invoice (de Proforma) | `{número_proforma}-INV` |
| Packing List (de Proforma) | `{número_proforma}-PL` |
| Invoice avulsa | número livre |
| Packing List (de Invoice avulsa) | `{número_invoice}-PL` |

---

## Observações Importantes

- **Postal Code do destinatário** é exibido no PDF junto com cidade e estado
- **end_use_es** é sempre buscado do catálogo de itens no momento da geração do PDF (não fica salvo no documento)
- **Cotação do dólar** é apenas referência para exibição em BRL — não afeta valores em USD/EUR do documento
- Documentos com `status: draft` podem ser editados e re-emitidos
- Documentos com `status: issued` ainda podem ser editados (botão "Atualizar Documento")