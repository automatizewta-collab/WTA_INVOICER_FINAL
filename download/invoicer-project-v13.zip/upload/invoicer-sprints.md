# Invoicer — Plano de Migração Base44 → Node.js com Motor de PDF Robusto

> Documento gerado a partir da análise de `invoicer.md`.
> Objetivo: substituir 100% do SDK **Base44** por bibliotecas open-source robustas e construir um motor de geração de PDF server-side profissional para documentos comerciais de exportação (Proforma, Invoice, Packing List) em **EN/ES**.

---

## 1. Análise do Arquivo `invoicer.md`

O sistema atual é um gerador/gestor de documentos comerciais de exportação com as seguintes características técnicas relevantes para a migração:

### 1.1 O que depende do Base44 hoje

| Camada | Uso no sistema atual | Trecho representativo |
|--------|---------------------|----------------------|
| **Persistência (CRUD)** | Entidades `Document`, `Item`, `Company` com `list / filter / create / update / delete` | `base44.entities.Document.filter({ number })` |
| **Autenticação** | Sessão do usuário corrente + logout | `base44.auth.me()` / `base44.auth.logout()` |
| **LLM** | Geração/auxílio de textos (presumivelmente traduções e notas) | `base44.integrations.Core.InvokeLLM({ prompt })` |
| **Upload de arquivos** | Logos de empresas e anexos | `base44.integrations.Core.UploadFile({ file })` |
| **Envio de e-mail** | Notificações de emissão de documentos | `base44.integrations.Core.SendEmail({ to, subject, body })` |
| **Geração de PDF** | HTML puro no frontend + `window.print()` manual do usuário (`Ctrl+P`) | `generatePrintableHTML` em `Documents.jsx` |

### 1.2 Pontos críticos identificados

1. **PDF não é determinístico** — depende do navegador do usuário, do driver de impressão e da ação manual (`Ctrl+P`). Inviável para automação, envio por e-mail em background e arquivamento fiscal.
2. **`end_use_es` não é persistido** — sempre lido do catálogo no momento da geração do PDF. Esse acoplamento precisa ser preservado (ou resolvido com snapshot) na migração.
3. **Fluxo de criação em cascata** — Proforma gera Invoice (`-INV`) + Packing List (`-PL`); Invoice gera Packing List. Sincronização reversa por sufixo.
4. **Numeração `AAMMXXXXXX`** — convenção de 10 dígitos que precisa de controle de sequência atômico (lock/concorrência).
5. **Multi-idioma EN/ES** — precisa de i18n no backend, não apenas no frontend.
6. **Cotação do dólar** — apenas referência BRL para exibição; não afeta valores USD/EUR.
7. **Estruturas aninhadas** (`items`, `shipment_details.boxes`, `financial_details`, `notes`) — precisam de modelagem relacional ou JSON tipado.

### 1.3 Princípios da migração

- **Substituir, não reimplementar** o SDK Base44 por equivalentes open-source maduros.
- **PDF server-side determinístico** — abolir a dependência de `Ctrl+P`.
- **Manter contratos de domínio** (campos, fluxos, numeração) para preservar regra de negócio.
- **TypeScript end-to-end** com tipagem estrita nos limites de sistema (Zod).
- **API-first** — toda regra exposta via REST, consumida pelo front Next.js.

---

## 2. Mapeamento de Bibliotecas: Base44 → Substitutas

### 2.1 Tabela principal de substituição

| Componente Base44 | Biblioteca recomendada | Versão alvo | Alternativas consideradas | Justificativa |
|-------------------|----------------------|-------------|--------------------------|---------------|
| `base44.entities.*` (CRUD) | **Prisma ORM** + `@prisma/client` | 5.x | TypeORM, Drizzle, Mongoose, Sequelize | Schema declarativo, migrations type-safe, DX superior, já no stack |
| `base44.auth.me()/logout()` | **NextAuth.js v4** (`next-auth`) | 4.24.x | Lucia, Passport.js, Clerk, Auth0, JWT puro | Já no stack, suporta credentials + OAuth, sessões JWT/DB |
| `base44.integrations.Core.InvokeLLM` | **z-ai-web-dev-sdk** (GLM-4.6) | latest | OpenAI SDK, Anthropic SDK, LangChain, Vercel AI SDK | SDK nativo Z.ai, sem custo adicional de tokens, multimodal |
| `base44.integrations.Core.UploadFile` | **Multer** + **`@aws-sdk/client-s3`** + **Sharp** | 1.4.x / 3.x / 0.33.x | Formidable, Busboy, Cloudinary, Uploadcare | Padrão de facto Node, S3-compatível (MinIO/AWS/Backblaze), Sharp p/ otimização |
| `base44.integrations.Core.SendEmail` | **Nodemailer** + **React Email** + **@react-email/components** | 6.9.x / 3.x | Resend, SendGrid, AWS SES, Postmark | SMTP flexível, templates React tipados, preview em dev |
| **PDF** (atualmente HTML + `Ctrl+P`) | **Puppeteer** + **Handlebars** + **pdf-lib** + **PDFKit** + **bwip-js** | 23.x / 4.x / 1.17.x / 0.15.x / 4.x | Playwright PDF, pdfmake, jsPDF, `@react-pdf/renderer`, html-pdf-node | Stack combinada para fidelidade visual (Puppeteer), manipulação (pdf-lib), controle fino (PDFKit) e código de barras (bwip-js) |

### 2.2 Stack de PDF robusta (detalhamento)

A geração de PDF é o coração do sistema e o ponto mais frágil da versão atual. A stack abaixo cobre **todos** os cenários identificados no `invoicer.md`:

| Biblioteca | Papel no sistema | Quando usar |
|-----------|------------------|-------------|
| **Puppeteer** | Renderização HTML→PDF em Chromium headless server-side | Proforma, Invoice (layouts complexos com tabelas, logos, cabeçalho/rodapé) |
| **Handlebars** | Template engine para montar HTML com dados tipados | Compilação dos 3 modelos de documento em EN/ES |
| **pdf-lib** | Manipulação pós-geração | Merge de múltiplos PDFs, watermark, metadadas XMP, numeração de páginas, assinatura digital (PAdES), inserção de páginas em branco |
| **PDFKit** | Geração programática de PDF do zero | Packing List tabular denso, código de barras, layout de etiquetas de caixa |
| **bwip-js** | Código de barras | GS1-128 / Code128 para AWB e tracking de embarque |
| **qrcode** | QR Codes | Link de validação do documento (`/api/documents/:id/verify`) |
| **Sharp** | Processamento de imagens | Redimensionamento/otimização de logos antes do embed |
| **pdf-parse** | Validação automatizada | Testes de regressão visual — extrair texto do PDF gerado e comparar snapshot |

### 2.3 Justificativa da escolha Puppeteer sobre `@react-pdf/renderer`

| Critério | Puppeteer + Handlebars | `@react-pdf/renderer` |
|----------|----------------------|----------------------|
| Fidelidade ao HTML/CSS existente | ✅ 100% (reaproveita templates atuais) | ❌ Reescrita total em componentes React-PDF |
| Flexibilidade de layout (flexbox, grid, print CSS) | ✅ Total | ⚠️ Subconjunto limitado |
| Velocidade de migração | ✅ Alta | ❌ Baixa |
| Performance (geração) | ⚠️ ~300–800ms/doc (com pool) | ✅ ~100–200ms/doc |
| Custo de manutenção de templates | ✅ Baixo (HTML/CSS) | ⚠️ Médio (componentes próprios) |
| Manipulação avançada (merge, assinatura) | ✅ Via pdf-lib | ⚠️ Limitada |

**Decisão:** Puppeteer como motor principal (maior fidelidade e velocidade de migração) + pdf-lib para pós-processamento + PDFKit para casos específicos (Packing List denso + código de barras).

### 2.4 Bibliotecas complementares de infraestrutura

| Função | Biblioteca |
|--------|-----------|
| Validação de schema | **Zod** |
| Logging estruturado | **pino** + `pino-pretty` |
| HTTP client (cotação dólar Bacen) | **ky** ou `undici` |
| Filas/jobs (geração de PDF em background, e-mail) | **BullMQ** + Redis (ou `p-queue` para fila in-process se sem Redis) |
| Testes E2E | **Playwright** |
| Testes unitários | **Vitest** |
| Containerização | **Docker** + `docker-compose` (Postgres + Redis + MinIO) |
| Variáveis de ambiente | **`@t3-oss/env-nextjs`** + Zod |

---

## 3. Arquitetura-Alvo (visão geral)

```
┌──────────────────────────────────────────────────────────────┐
│                    Next.js 16 (App Router)                   │
│  /  /Documents  /NewDocument  /EditDocument  /Items          │
│  /Companies  /Settings  +  API Routes (/api/*)               │
└──────────────────────────────────────────────────────────────┘
                              │
       ┌──────────────────────┼──────────────────────┐
       ▼                      ▼                      ▼
┌─────────────┐      ┌────────────────┐     ┌─────────────────┐
│  Prisma ORM │      │  NextAuth v4   │     │  Service Layer  │
│  (Postgres) │      │  (JWT + DB)    │     │  (Zod + DTOs)   │
└─────────────┘      └────────────────┘     └─────────────────┘
                                                     │
       ┌──────────────────┬──────────────────┬───────┴──────────┐
       ▼                  ▼                  ▼                  ▼
┌─────────────┐   ┌──────────────┐   ┌──────────────┐   ┌─────────────┐
│ PDF Engine  │   │ LLM Service  │   │ Upload Svc   │   │ Email Svc   │
│ Puppeteer + │   │ z-ai-web-    │   │ Multer + S3  │   │ Nodemailer  │
│ Handlebars +│   │ dev-sdk GLM  │   │ + Sharp      │   │ + React     │
│ pdf-lib +   │   │              │   │              │   │   Email     │
│ PDFKit      │   │              │   │              │   │             │
└─────────────┘   └──────────────┘   └──────────────┘   └─────────────┘
       │
       ▼
┌──────────────────────────────────────────┐
│  BullMQ Queue (geração PDF, envio email) │
│  Worker separado para jobs pesados       │
└──────────────────────────────────────────┘
```

---

## 4. Plano de Execução — 6 Sprints

> **Duração total estimada:** 13 semanas (≈ 3 meses) com 1 dev full-time.
> **Cadência:** Sprints de ~2 semanas (Sprint 5 tem 3 semanas por ser o bloco mais crítico).

---

### 🟦 Sprint 1 — Fundação e Infraestrutura

**Duração:** 2 semanas
**Objetivo:** Estabelecer a base do projeto Next.js 16 com TypeScript, configurar banco de dados, logging, env vars e CI.

#### Tarefas
1. Inicializar projeto Next.js 16 (App Router) + TypeScript 5 + Tailwind CSS 4 + shadcn/ui (New York).
2. Configurar ESLint, Prettier, EditorConfig, `eslint-plugin-unused-imports`, Husky + lint-staged.
3. Instalar e configurar **Prisma ORM** com provider PostgreSQL (dev = SQLite para portabilidade).
4. Criar `docker-compose.yml` com: `postgres:16`, `redis:7`, `minio` (S3 local), `mailhog` (SMTP dev).
5. Configurar `@t3-oss/env-nextjs` + Zod para validar `DATABASE_URL`, `REDIS_URL`, `S3_*`, `SMTP_*`, `AUTH_SECRET`, `ZAI_API_KEY`.
6. Setup de **pino** com `pino-pretty` em dev e JSON em prod; middleware de request logging.
7. Criar `/api/health` (DB, Redis, S3 connectivity).
8. Configurar GitHub Actions: `lint`, `tsc --noEmit`, `prisma migrate status` em PR.
9. Definir estrutura de pastas:
   ```
   src/
     app/(auth)/, app/(app)/, app/api/
     lib/db.ts, lib/auth.ts, lib/env.ts, lib/logger.ts
     modules/{documents,items,companies,users,pdf,llm,upload,email}/
       {service.ts, dto.ts, repository.ts, route.ts}
   prisma/schema.prisma
   ```

#### Bibliotecas instaladas
`next`, `react`, `typescript`, `tailwindcss`, `prisma`, `@prisma/client`, `@t3-oss/env-nextjs`, `zod`, `pino`, `pino-pretty`, `eslint`, `prettier`, `husky`, `lint-staged`.

#### Entregáveis
- ✅ Projeto sobe com `bun run dev` na porta 3000.
- ✅ `/api/health` retorna `200` com status dos serviços.
- ✅ `docker compose up` sobe Postgres + Redis + MinIO + MailHog.
- ✅ CI verde em PR.

#### Critérios de aceite
- Lint sem erros.
- `prisma migrate dev` roda sem falhas.
- Log estruturado em JSON visível em `dev.log`.

---

### 🟩 Sprint 2 — Camada de Dados e Entidades (substitui `base44.entities.*`)

**Duração:** 2 semanas
**Objetivo:** Modelar e expor CRUD completo de `Document`, `Item`, `Company` via Prisma + API REST tipada.

#### Tarefas
1. **Schema Prisma** completo:
   - `User` (id, email, name, role, passwordHash)
   - `Company` (id, name, type enum sender/recipient, contact_name, address, city, postal_code, state, country, email, phone, cnpj, state_registration, is_default, logo_url, bank_details, mid_code)
   - `Item` (id, code, name_pt, name_en, name_es, unit_value_usd Decimal, gross_weight Decimal, net_weight Decimal, htsus_code, end_use, end_use_es, sterile_at_import enum YES/NO)
   - `Document` (id, document_type enum proforma/invoice/packing_list, status enum draft/issued, language enum en/es, number String @unique, date DateTime, sender_id, recipient_id, items Json, dollar_exchange_rate Decimal, currency enum USD/EUR, htsus_column_title, show_sterile_column Boolean, origin_proforma_id, shipment_details Json, financial_details Json, notes Json, pdf_url, created_at, updated_at)
   - `DocumentSequence` (id, year_month, last_number) — controle atômico de numeração `AAMMXXXXXX`.
2. Gerar migrations + seed com empresas, itens e 1 proforma de exemplo.
3. **Repository pattern** em `modules/*/repository.ts` usando `PrismaClient` injetado.
4. **Service layer** com regras de domínio (não expor Prisma diretamente).
5. **DTOs com Zod** para cada operação (create/update) — validação no limite da API.
6. **API Routes REST**:
   - `GET/POST /api/companies`
   - `GET/PATCH/DELETE /api/companies/:id`
   - `GET/POST /api/items`
   - `GET/PATCH/DELETE /api/items/:id`
   - `GET /api/documents` (filtros: `type`, `status`, `number`, `sender_id`, paginação `cursor`/`offset`)
   - `POST /api/documents`
   - `GET/PATCH /api/documents/:id`
   - `DELETE /api/documents/:id`
   - `POST /api/documents/:id/items/refresh` — re-busca `end_use`/`end_use_es` do catálogo (preserva regra original).
7. Helper `next-safe-action` ou handler padrão com `try/catch`, retorno `Result<T, E>` tipado.
8. Paginação por cursor + filtros de busca textual (`name`, `number`) via `Prisma.where`.

#### Bibliotecas instaladas
`@prisma/client`, `zod`, `nanoid` (IDs opacos), `decimal.js` (cálculos monetários seguros).

#### Entregáveis
- ✅ Schema Prisma versionado + migrations aplicadas.
- ✅ Endpoints CRUD funcionais via Postman/Insomnia.
- ✅ Seed populando 3 empresas, 10 itens, 1 proforma.
- ✅ Documentação OpenAPI gerada a partir das rotas (Swagger UI em `/api/docs`).

#### Critérios de aceite
- `POST /api/documents` cria documento com `items` JSON validado por Zod.
- `GET /api/documents?type=invoice&status=issued` retorna apenas invoices emitidas.
- Numeração de documento é atômica sob concorrência (teste com 10 requisições simultâneas → 10 números distintos).

---

### 🟨 Sprint 3 — Autenticação e Autorização (substitui `base44.auth.*`)

**Duração:** 2 semanas
**Objetivo:** Implementar auth de usuários com NextAuth.js v4, controle de acesso por papel e auditoria.

#### Tarefas
1. Configurar **NextAuth.js v4** com:
   - Provider **Credentials** (email + senha com `bcrypt`).
   - Provider **Google OAuth** (opcional, via `GOOGLE_CLIENT_ID/SECRET`).
   - Strategy **JWT** com `AUTH_SECRET`.
2. Model `User` + `Account` + `Session` (adaptador Prisma do NextAuth).
3. Campo `role` enum `admin | editor | viewer` com middleware de autorização.
4. Páginas: `/login`, `/register` (admin-only), `/forgot-password`, `/reset-password`.
5. **Middleware** (`middleware.ts`) protegendo rotas `(app)/*` e `/api/*` (exceto `/api/health`, `/api/auth/*`).
6. **Audit log** — tabela `AuditEvent` (userId, action, entity, entityId, metadata, ip, userAgent) populada em todas as mutações.
7. Hook `useSession()` no front + componente `<ProtectedRoute>`.
8. Rate limiting em `/api/auth/*` via `upstash/ratelimit` (ou in-memory com `lru-cache`).

#### Bibliotecas instaladas
`next-auth@4.24.x`, `@auth/prisma-adapter`, `bcryptjs`, `@upstash/ratelimit`, `lru-cache`.

#### Entregáveis
- ✅ Login funcional com sessão JWT persistente.
- ✅ Rotas protegidas redirecionam para `/login` quando desautenticado.
- ✅ Auditoria registra quem criou/editou/apagou cada documento.
- ✅ Reset de senha por e-mail (integração com Sprint 4).

#### Critérios de aceite
- Usuário `viewer` não consegue `POST /api/documents` (403).
- 5 tentativas de login falhas → rate limit 429 por 15 min.
- `base44.auth.me()` substituído por `useSession()` no front e `getServerSession()` no back.

---

### 🟧 Sprint 4 — Integrações: LLM, Upload, Email (substitui `base44.integrations.Core.*`)

**Duração:** 2 semanas
**Objetivo:** Implementar os 3 serviços de integração do `Core` Base44 com bibliotecas open-source.

#### 4.1 LLM Service (substitui `InvokeLLM`)

**Biblioteca:** `z-ai-web-dev-sdk` (SDK oficial Z.ai — GLM-4.6)

Casos de uso:
- **Tradução EN↔ES** de nomes de itens e `end_use` (preenche `name_es`/`end_use_es` automaticamente ao cadastrar item).
- **Geração de notas** automáticas para documentos (ex.: "Payment terms: 30 days net").
- **Resumo do dashboard** ("Você tem 3 invoices emitidas esta semana totalizando $12,500").

Implementação:
- `modules/llm/service.ts` com `translateText(text, from, to)`, `generateNotes(document)`, `summarize(documents[])`.
- Cache em memória (LRU) para traduções repetidas.
- Fallback: se Z.ai indisponível, retorna texto original + warning no log.

#### 4.2 Upload Service (substitui `UploadFile`)

**Bibliotecas:** `multer` + `@aws-sdk/client-s3` + `sharp`

Casos de uso:
- Upload de **logo de empresa** (PNG/SVG, máx 2MB, redimensionado para 400×200 pelo Sharp).
- Upload de **anexos** de documento (PDF, DOCX — armazenados no S3/MinIO).
- Serviço de download assinado (URL pré-assinada com expiração de 1h).

Implementação:
- `modules/upload/route.ts` — `POST /api/upload` (multipart).
- `UploadService` abstrai storage (S3 em prod, filesystem em dev).
- Validação de MIME type e tamanho via Zod + Multer limits.
- Antivírus opcional: hook para ClamAV em prod.

#### 4.3 Email Service (substitui `SendEmail`)

**Bibliotecas:** `nodemailer` + `react-email` + `@react-email/components`

Templates React Email:
- `DocumentIssuedEmail` — notifica destinatário quando invoice é emitida (com link do PDF).
- `WelcomeEmail` — boas-vindas pós-cadastro.
- `PasswordResetEmail` — token de reset.

Implementação:
- `modules/email/service.ts` com `sendEmail({ to, subject, template, props })`.
- SMTP em dev = MailHog (`smtp://mailhog:1025`); em prod = SES/SMTP real.
- Preview de templates em `/emails/preview/:template` (modo dev).
- Fila via BullMQ para envio assíncrono (evita bloquear request).

#### 4.4 Bônus: Webhook de cotação do dólar
- Cron diário (às 09:00 BRT) via BullMQ scheduler buscando cotação USD/BRL no Bacen PTAX.
- Cacheia em `AppSetting` (key/value) para uso em `dollar_exchange_rate` default.

#### Bibliotecas instaladas
`z-ai-web-dev-sdk`, `multer`, `@aws-sdk/client-s3`, `@aws-sdk/s3-request-presigner`, `sharp`, `nodemailer`, `react-email`, `@react-email/components`, `bullmq`, `ioredis`, `ky` (HTTP client p/ Bacen), `node-cron` (fallback se sem Redis).

#### Entregáveis
- ✅ `POST /api/llm/translate` traduz nome de item EN→ES.
- ✅ `POST /api/upload` salva logo no MinIO e retorna URL.
- ✅ Emissão de documento dispara `DocumentIssuedEmail` visível no MailHog.
- ✅ Cotação do dólar atualizada diariamente em `AppSetting`.

#### Critérios de aceite
- Logo de 5MB é rejeitado com 413.
- Tradução EN→ES de "Surgical gloves" retorna "Guantes quirúrgicos".
- E-mail enviado aparece em `http://localhost:8025` (MailHog UI).

---

### 🟥 Sprint 5 — Motor de Geração de PDF Robusto (núcleo do projeto)

**Duração:** 3 semanas (sprint expandido — é o bloco mais crítico)
**Objetivo:** Substituir 100% o modelo "HTML + Ctrl+P" por geração server-side determinística, multi-idioma e manipulável.

#### 5.1 Arquitetura do motor de PDF

```
Document (DB) ──► DTO ──► Handlebars Template (EN|ES) ──► HTML
                                                              │
                                                              ▼
                                              Puppeteer (Chromium headless)
                                                              │
                                                              ▼
                                                          PDF bruto
                                                              │
                                              ┌───────────────┼───────────────┐
                                              ▼               ▼               ▼
                                        pdf-lib         bwip-js         qrcode
                                   (watermark,      (Code128 AWB)   (verify link)
                                    merge, metadata,
                                    signature)
                                              │
                                              ▼
                                          PDF final ──► S3 ──► pdf_url (DB)
```

#### 5.2 Templates Handlebars (3 modelos × 2 idiomas = 6 templates)

Localização: `modules/pdf/templates/{proforma,invoice,packing_list}.{en,es}.hbs`

Cada template recebe um `DocumentPdfDTO` tipado:
```ts
interface DocumentPdfDto {
  document: Document & { sender: Company; recipient: Company };
  items: Array<ItemSnapshot>;   // inclui end_use/end_use_es do catálogo no momento da geração
  shipment: ShipmentDetails;
  financial: FinancialDetails;
  notes: string[];
  i18n: Record<string, string>; // textos fixos no idioma do documento
  companyLogoBase64?: string;   // embed inline para não depender de URL externa
  generatedAt: string;
  qrCodeVerifyBase64: string;
}
```

**Regra crítica preservada:** `end_use_es` é sempre lido do catálogo de itens no momento da geração (snapshot), nunca do documento salvo — exatamente como no sistema atual.

#### 5.3 Puppeteer — renderização HTML→PDF

- **Pool de browsers** (reuso de `browser` + `page` para reduzir overhead de cold start).
- Configurações:
  - `format: 'A4'`, `printBackground: true`
  - `margin: { top: '20mm', bottom: '20mm', left: '15mm', right: '15mm' }`
  - `displayHeaderFooter: true` com template de rodapé paginado (`<span class="pageNumber"></span>/<span class="totalPages"></span>`)
  - `preferCSSPageSize: true`
- CSS print-specific: `@page`, `page-break-before: always` para multi-página.
- Embed de logos como `data:image/png;base64,...` (sem requisição externa → PDF self-contained).

#### 5.4 pdf-lib — pós-processamento

Operações implementadas em `PdfPostProcessor`:
1. **Metadados XMP**: Title (número do documento), Author (empresa remetente), Subject (`Proforma 2605123456`), CreationDate.
2. **Watermark** (opcional, para `status: draft`): texto "DRAFT" diagonal em vermelho, 30% opacidade.
3. **Numeração de páginas** customizada (caso rodapé do Puppeteer não seja suficiente).
4. **Merge**: se documento tiver anexos, anexa PDFs extras do S3 ao final.
5. **Assinatura digital** (PAdES básico — Sprint futuro avançaria para LTV): placeholder com certificado A1.
6. **QR Code de validação** no rodapé da página 1: aponta para `/api/documents/:id/verify` (público, sem auth).

#### 5.5 PDFKit — Packing List tabular denso + código de barras

Packing List tem layout altamente tabular (caixas, dimensões, pesos). Em vez de HTML, geração programática com PDFKit:
- Tabela de caixas com `PDFDocument.table()` (via `pdfkit-table`).
- **bwip-js** gera Code128 do AWB embutido no header.
- Layout de **etiquetas de caixa** (4×10 por página A4) para impressão térmica.

#### 5.6 Pipeline de geração

`POST /api/documents/:id/pdf`:
1. Busca documento + sender + recipient.
2. Re-busca itens do catálogo (snapshot de `end_use`/`end_use_es`).
3. Seleciona template `.hbs` por (`document_type`, `language`).
4. Renderiza HTML com Handlebars.
5. Puppeteer gera PDF bruto → Buffer.
6. `PdfPostProcessor` aplica metadados + watermark + QR + merge.
7. Upload do PDF final para S3 (`documents/{id}/{number}.pdf`).
8. Atualiza `document.pdf_url`.
9. Retorna URL pré-assinada (1h) para download.

**Modo background:** Para lotes (ex.: regenerar todos os PDFs do mês), job BullMQ `generate-pdf` com concorrência controlada (max 3 simultâneos para não estourar RAM do Chromium).

#### 5.7 Performance e resiliência

- **Pool de browsers**: 2 instâncias Chromium reutilizadas via `generic-pool`.
- **Timeout**: 30s por geração; aborta e marca erro se exceder.
- **Cache de template compilado**: Handlebars pré-compilado em boot da app.
- **Fallback**: se Puppeteer falhar (ex.: OOM), tentar PDFKit como fallback para layouts simples.
- **Observabilidade**: métrica `pdf_generation_duration_seconds` (Histogram) + log estruturado com `documentId`, `template`, `durationMs`.

#### 5.8 Pré-visualização no front

- `GET /api/documents/:id/preview` retorna HTML renderizado (sem PDF) para preview inline em `<iframe>` no `EditDocument`.
- Botão "Baixar PDF" dispara `POST /api/documents/:id/pdf` e abre o link pré-assinado.

#### Bibliotecas instaladas
`puppeteer`, `handlebars`, `pdf-lib`, `pdfkit`, `pdfkit-table`, `bwip-js`, `qrcode`, `generic-pool`, `html-to-text` (para fallback acessibilidade).

#### Entregáveis
- ✅ 3 templates (Proforma, Invoice, Packing List) × 2 idiomas (EN, ES) = 6 templates `.hbs`.
- ✅ `POST /api/documents/:id/pdf` gera PDF em < 1s e atualiza `pdf_url`.
- ✅ PDF com metadados XMP, QR de validação e paginação.
- ✅ Packing List com código de barras Code128 do AWB.
- ✅ Preview inline no `EditDocument`.
- ✅ Job BullMQ para regeneração em lote.

#### Critérios de aceite
- PDF gerado é **byte-estável** para o mesmo input (hash determinístico) — habilita cache e diff.
- Texto extraído via `pdf-parse` contém número do documento, nomes de itens em ES (quando `language=es`) e totals.
- Logo da empresa aparece embedido (sem requisição de rede ao abrir o PDF offline).
- Watermark "DRAFT" visível em documentos com `status=draft`.
- 100 gerações consecutivas em lote completam sem OOM nem travamento do Chromium.

---

### 🟪 Sprint 6 — Regras de Negócio, Sincronização e Polimento

**Duração:** 2 semanas
**Objetivo:** Implementar fluxos de cascata (Proforma→Invoice+PL), sincronização reversa, dashboard, settings, testes E2E e deploy.

#### 6.1 Fluxos de criação em cascata (regra de negócio crítica)

Implementar em `DocumentService.create()`:

| Input | Documentos criados |
|-------|-------------------|
| `type=proforma` | Proforma `{number}` + Invoice `{number}-INV` + Packing List `{number}-PL` (financial zerado) |
| `type=invoice` | Invoice `{number}` + Packing List `{number}-PL` |
| `type=packing_list` | apenas Packing List `{number}` |

- Tudo em **transação Prisma** (rollback atômico se qualquer insert falhar).
- Numeração atômica via `DocumentSequence` com `SELECT ... FOR UPDATE` (Postgres) ou transação serializada (SQLite dev).

#### 6.2 Fluxos de edição e sincronização

| Cenário | Comportamento |
|---------|--------------|
| Editar Proforma | Atualiza Proforma + busca Invoice filha pelo número **original** + `-INV` (snapshot antes do update) + busca PL por número original + `-PL`. Se encontrar → atualiza; senão → cria. |
| Editar Invoice | Atualiza Invoice + busca PL pelo número **novo** + `-PL`. Se encontrar → sincroniza itens/embarque/notas; senão → apenas avisa (toast). |
| Sincronizar PL com Invoice (botão) | Remove sufixo `-PL` do número atual → localiza Invoice → copia itens, datas, embarque e notas da Invoice para o PL. |

#### 6.3 Dashboard (`/`)

- Cards de KPIs: total de documentos por tipo, valor total emitido no mês, documentos em `draft` pendentes.
- `RecentDocuments` — últimos 10 documentos com link para edição.
- Gráfico de barras (Recharts) — documentos emitidos por mês (últimos 6).
- Atalhos: "Nova Proforma", "Nova Invoice", "Novo Packing List".

#### 6.4 Settings (`/Settings`)

- Empresa remetente padrão (toggle `is_default`).
- Templates de e-mail editáveis (editor Monaco com preview React Email).
- Configuração de numeração (prefixo, ano de 2 dígitos, contador).
- Chaves de API (Z.ai, SMTP, S3) — mascaradas, editáveis apenas por `admin`.
- Webhook de cotação do dólar (toggle on/off + último valor).

#### 6.5 Frontend — páginas restantes

- `/Documents` — tabela com filtros (tipo, status, busca por número), ações em massa (regenerar PDF, enviar por e-mail).
- `/NewDocument` — formulário multi-step com `DocumentItemsTable`, `ShipmentDetailsForm`, `NotesForm`, `LanguageToggle` (reimplementar do zero em React + shadcn/ui).
- `/EditDocument?id={id}` — mesmo formulário em modo edição + botão "Sincronizar PL com Invoice" (condicional).
- `/Items` — CRUD de catálogo com importação CSV (PapaParse).
- `/Companies` — CRUD de empresas com upload de logo.

#### 6.6 Testes E2E (Playwright)

Cenários cobertos:
1. Login → criar proforma → validar 3 documentos criados (Proforma + INV + PL).
2. Editar proforma → mudar número → validar Invoice filha atualizada.
3. Gerar PDF → validar download e `pdf_url` preenchido.
4. Trocar idioma para ES → gerar PDF → validar nome_es no texto extraído.
5. Sincronizar PL com Invoice → validar itens copiados.

#### 6.7 Deploy e observabilidade

- **Dockerfile** multi-stage: build → runtime Node 20 Alpine + Chromium (para Puppeteer).
- **docker-compose.prod.yml** com Postgres, Redis, MinIO, app.
- Health check em `/api/health` para orquestrador.
- Métricas Prometheus em `/api/metrics` (pdf_generation_duration, llm_calls, email_sent).
- Backup diário do Postgres via `pg_dump` → S3.

#### Bibliotecas instaladas
`@playwright/test`, `papaparse`, `recharts`, `@monaco-editor/react`, `prom-client` (métricas).

#### Entregáveis
- ✅ Fluxos de cascata funcionais com testes E2E.
- ✅ Sincronização PL↔Invoice operacional.
- ✅ Dashboard com KPIs e gráfico.
- ✅ Settings completo.
- ✅ Deploy Docker funcional.
- ✅ Documentação de operação (runbook).

#### Critérios de aceite
- Criar Proforma `2605123456` resulta em 3 documentos com números `2605123456`, `2605123456-INV`, `2605123456-PL`.
- Editar Proforma e mudar número para `2605123457` atualiza filhas (mantém referência pelo número **original**).
- Teste E2E do fluxo completo (criar→editar→gerar PDF→sincronizar) passa no CI.
- App sobe em produção via `docker compose up` sem ajustes manuais.

---

## 5. Resumo Comparativo Final

| Aspecto | Sistema Atual (Base44) | Sistema Novo (Node.js) |
|---------|----------------------|----------------------|
| **Persistência** | `base44.entities.*` (proprietário) | Prisma ORM + PostgreSQL (open-source) |
| **Auth** | `base44.auth.*` (proprietário) | NextAuth.js v4 + JWT (open-source) |
| **LLM** | `base44.integrations.Core.InvokeLLM` | z-ai-web-dev-sdk GLM-4.6 |
| **Upload** | `base44.integrations.Core.UploadFile` | Multer + S3 + Sharp |
| **Email** | `base44.integrations.Core.SendEmail` | Nodemailer + React Email |
| **PDF** | HTML + `Ctrl+P` manual do usuário | Puppeteer + Handlebars + pdf-lib + PDFKit + bwip-js (server-side determinístico) |
| **Multi-idioma** | Switch front (EN/ES) | i18n no backend + 6 templates Handlebars |
| **Determinismo** | ❌ Depende do navegador do usuário | ✅ Byte-estável, hash determinístico |
| **Automação** | ❌ Impossível (`Ctrl+P` manual) | ✅ Job BullMQ para geração em lote |
| **Manipulação** | ❌ Nenhuma | ✅ Merge, watermark, assinatura, QR, código de barras |
| **Custo de vendor lock-in** | 🔴 Alto (Base44) | 🟢 Zero (100% open-source self-hostable) |

---

## 6. Cronograma Consolidado

| Sprint | Duração | Foco | Risco |
|--------|---------|------|-------|
| 1 | 2 sem | Fundação + Infra | 🟢 Baixo |
| 2 | 2 sem | Camada de dados (CRUD) | 🟢 Baixo |
| 3 | 2 sem | Autenticação + Autorização | 🟡 Médio (OAuth) |
| 4 | 2 sem | LLM + Upload + Email | 🟡 Médio (integrações externas) |
| 5 | 3 sem | **Motor de PDF robusto** | 🔴 Alto (núcleo do projeto) |
| 6 | 2 sem | Regras de negócio + Sync + Deploy | 🟡 Médio |
| **Total** | **13 sem** | **App completo em produção** | |

---

## 7. Riscos e Mitigações

| Risco | Probabilidade | Impacto | Mitigação |
|-------|--------------|---------|----------|
| Puppeteer OOM em lotes grandes | Média | Alto | Pool de browsers + concorrência limitada (3) + worker dedicado |
| Concorrência na numeração `AAMMXXXXXX` | Baixa | Alto | `SELECT FOR UPDATE` em Postgres + retry com backoff |
| `end_use_es` divergente entre catálogo e PDF | Média | Médio | Snapshot no momento da geração + log de divergência |
| Z.ai LLM indisponível | Baixa | Médio | Fallback graceful (retorna EN) + cache de traduções |
| Custos de S3 em escala | Média | Médio | Lifecycle policy (PDFs → Glacier após 90 dias) |
| Chromium vulnerabilidade de segurança | Média | Alto | Imagem Docker pinada + `--no-sandbox` apenas em container isolado |

---

## 8. Próximos Passos Imediatos

1. **Aprovar este plano** com stakeholders.
2. **Setup do repositório** e Sprint 1 (fundação) — pode começar imediatamente.
3. **Validar stack de PDF** com um POC rápido em Sprint 1 (gerar 1 PDF de Invoice com Puppeteer) para de-riskar Sprint 5.
4. **Definir ambiente de deploy** (AWS ECS / Fly.io / VPS Docker) antes do Sprint 6.

---

*Documento gerado automaticamente a partir da análise de `invoicer.md`.*
*Stack-alvo: Next.js 16 + TypeScript + Prisma + NextAuth + z-ai-web-dev-sdk + Puppeteer + pdf-lib.*
