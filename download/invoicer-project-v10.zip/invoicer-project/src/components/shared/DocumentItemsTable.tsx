"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Plus, Trash2 } from "lucide-react";
import type { DocumentItem, DocumentLanguage, Item } from "@/lib/types";

interface DocumentItemsTableProps {
  items: DocumentItem[];
  onChange: (items: DocumentItem[]) => void;
  catalogItems: Item[];
  language: DocumentLanguage;
  showSterileColumn: boolean;
  htsusColumnTitle?: string;
}

function getItemName(item: Item | undefined, language: DocumentLanguage) {
  if (!item) return "";
  if (language === "es" && item.nameEs) return item.nameEs;
  if (language === "en") return item.nameEn;
  return item.namePt;
}

function getLineTotal(item: DocumentItem): number {
  return item.quantity * item.unit_price * (1 - item.discount / 100);
}

export function DocumentItemsTable({
  items,
  onChange,
  catalogItems,
  language,
  showSterileColumn,
  htsusColumnTitle,
}: DocumentItemsTableProps) {
  const safeItems = Array.isArray(items) ? items : [];
  const addItem = () => {
    const newLine = safeItems.length > 0 ? Math.max(...safeItems.map((i) => i.line_number)) + 1 : 1;
    onChange([
      ...safeItems,
      {
        item_id: "",
        quantity: 1,
        unit_price: 0,
        discount: 0,
        line_number: newLine,
        gross_weight: 0,
        net_weight: 0,
        htsus_code: "",
        sterile_at_import: "NO",
      },
    ]);
  };

  const removeItem = (index: number) => {
    onChange(safeItems.filter((_, i) => i !== index));
  };

  const selectCatalogItem = (index: number, itemId: string) => {
    const catalogItem = catalogItems.find((c) => c.id === itemId);
    if (catalogItem) {
      const updated = [...safeItems];
      updated[index] = {
        ...updated[index],
        item_id: catalogItem.id,
        unit_price: catalogItem.unitValueUsd,
        gross_weight: catalogItem.grossWeight,
        net_weight: catalogItem.netWeight,
        htsus_code: catalogItem.htsusCode || "",
        sterile_at_import: catalogItem.sterileAtImport === "YES" ? "YES" : "NO",
      };
      onChange(updated);
    }
  };

  const updateItem = (
    index: number,
    field: keyof DocumentItem,
    value: string | number
  ) => {
    const updated = [...safeItems];
    (updated[index] as Record<string, string | number>)[field] = value;
    onChange(updated);
  };

  const htsusLabel = htsusColumnTitle || "HTSUS Code";

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium">Items</h3>
        <Button type="button" variant="outline" size="sm" onClick={addItem}>
          <Plus className="h-4 w-4 mr-1" />
          Add Item
        </Button>
      </div>

      <div className="border rounded-md overflow-auto max-h-[400px]">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12">#</TableHead>
              <TableHead className="min-w-[200px]">Item</TableHead>
              <TableHead className="min-w-[150px]">Description</TableHead>
              <TableHead className="w-20">Qty</TableHead>
              <TableHead className="w-28">Unit Price</TableHead>
              <TableHead className="w-20">Disc %</TableHead>
              <TableHead className="w-28">Line Total</TableHead>
              <TableHead className="w-24">Gross Wt</TableHead>
              <TableHead className="w-24">Net Wt</TableHead>
              <TableHead className="w-28">{htsusLabel}</TableHead>
              {showSterileColumn && (
                <TableHead className="w-20">Sterile</TableHead>
              )}
              <TableHead className="w-12" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {safeItems.length === 0 && (
              <TableRow>
                <TableCell
                  colSpan={showSterileColumn ? 12 : 11}
                  className="text-center py-8 text-muted-foreground text-sm"
                >
                  No items added. Click &quot;Add Item&quot; to begin.
                </TableCell>
              </TableRow>
            )}
            {safeItems.map((item, index) => {
              const catalogItem = catalogItems.find(
                (c) => c.id === item.item_id
              );
              const description = catalogItem
                ? getItemName(catalogItem, language)
                : "";

              return (
                <TableRow key={index}>
                  <TableCell className="text-muted-foreground text-xs">
                    {item.line_number}
                  </TableCell>
                  <TableCell>
                    <Select
                      value={item.item_id}
                      onValueChange={(val) => selectCatalogItem(index, val)}
                    >
                      <SelectTrigger className="h-8 text-xs">
                        <SelectValue placeholder="Select item..." />
                      </SelectTrigger>
                      <SelectContent>
                        {catalogItems.map((ci) => (
                          <SelectItem key={ci.id} value={ci.id}>
                            {ci.code} - {ci.nameEn}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell className="text-xs">{description}</TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      min={0}
                      value={item.quantity}
                      onChange={(e) =>
                        updateItem(
                          index,
                          "quantity",
                          parseFloat(e.target.value) || 0
                        )
                      }
                      className="h-8 text-xs"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      min={0}
                      step="0.01"
                      value={item.unit_price}
                      onChange={(e) =>
                        updateItem(
                          index,
                          "unit_price",
                          parseFloat(e.target.value) || 0
                        )
                      }
                      className="h-8 text-xs"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      value={item.discount}
                      onChange={(e) =>
                        updateItem(
                          index,
                          "discount",
                          parseFloat(e.target.value) || 0
                        )
                      }
                      className="h-8 text-xs"
                    />
                  </TableCell>
                  <TableCell className="text-xs font-medium">
                    {getLineTotal(item).toFixed(2)}
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      min={0}
                      step="0.01"
                      value={item.gross_weight}
                      onChange={(e) =>
                        updateItem(
                          index,
                          "gross_weight",
                          parseFloat(e.target.value) || 0
                        )
                      }
                      className="h-8 text-xs"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      min={0}
                      step="0.01"
                      value={item.net_weight}
                      onChange={(e) =>
                        updateItem(
                          index,
                          "net_weight",
                          parseFloat(e.target.value) || 0
                        )
                      }
                      className="h-8 text-xs"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      value={item.htsus_code}
                      onChange={(e) =>
                        updateItem(index, "htsus_code", e.target.value)
                      }
                      className="h-8 text-xs"
                      placeholder="0000.00.00"
                    />
                  </TableCell>
                  {showSterileColumn && (
                    <TableCell>
                      <Checkbox
                        checked={item.sterile_at_import === "YES"}
                        onCheckedChange={(checked) =>
                          updateItem(
                            index,
                            "sterile_at_import",
                            checked ? "YES" : "NO"
                          )
                        }
                      />
                    </TableCell>
                  )}
                  <TableCell>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => removeItem(index)}
                    >
                      <Trash2 className="h-3.5 w-3.5 text-destructive" />
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      {safeItems.length > 0 && (
        <div className="flex justify-end">
          <p className="text-sm font-medium">
            Total:{" "}
            <span className="text-base">
              ${safeItems.reduce((sum, item) => sum + getLineTotal(item), 0).toFixed(2)}
            </span>
          </p>
        </div>
      )}
    </div>
  );
}