"use client";

import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { useAppStore } from "@/lib/store";
import type {
  DocumentWithRelations,
  DocumentType,
  DocumentLanguage,
  Currency,
  DocumentItem,
  ShipmentDetails,
  FinancialDetails,
  Company,
  Item,
} from "@/lib/types";
import { DocumentItemsTable } from "@/components/shared/DocumentItemsTable";
import { ShipmentDetailsForm } from "@/components/shared/ShipmentDetailsForm";
import { NotesForm } from "@/components/shared/NotesForm";
import { apiFetch } from "@/lib/utils";
import {
  ArrowLeft,
  Save,
  Send,
  FileDown,
  RefreshCw,
} from "lucide-react";

const emptyShipment: ShipmentDetails = {
  carrier: "",
  incoterms: "",
  origin_port: "",
  destination_port: "",
  shipment_date: "",
  awb: "",
  boxes: [],
  gross_weight: 0,
  net_weight: 0,
};

const emptyFinancial: FinancialDetails = {
  discount: 0,
  shipping_cost: 0,
  insurance: 0,
  bank_fees: 0,
  total_value: 0,
};

function calculateTotal(
  items: DocumentItem[],
  financial: FinancialDetails
): number {
  const subtotal = items.reduce((sum, item) => {
    return sum + item.quantity * item.unit_price * (1 - item.discount / 100);
  }, 0);
  return (
    subtotal * (1 - (financial.discount || 0) / 100) +
    (financial.shipping_cost || 0) +
    (financial.insurance || 0) +
    (financial.bank_fees || 0)
  );
}

export function EditDocumentView() {
  const editDocumentId = useAppStore((s) => s.editDocumentId);
  const navigate = useAppStore((s) => s.navigate);
  const queryClient = useQueryClient();

  const [documentType, setDocumentType] = useState<DocumentType>("proforma");
  const [status, setStatus] = useState<string>("draft");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [language, setLanguage] = useState<DocumentLanguage>("en");
  const [currency, setCurrency] = useState<Currency>("USD");
  const [dollarExchangeRate, setDollarExchangeRate] = useState<number | null>(
    null
  );
  const [htsusColumnTitle, setHtsusColumnTitle] = useState("");
  const [showSterileColumn, setShowSterileColumn] = useState(false);
  const [senderId, setSenderId] = useState("");
  const [recipientId, setRecipientId] = useState("");
  const [items, setItems] = useState<DocumentItem[]>([]);
  const [shipmentDetails, setShipmentDetails] =
    useState<ShipmentDetails>(emptyShipment);
  const [financialDetails, setFinancialDetails] =
    useState<FinancialDetails>(emptyFinancial);
  const [notes, setNotes] = useState<string[]>([]);

  const { data: doc, isLoading: docLoading } = useQuery<DocumentWithRelations>({
    queryKey: ["document", editDocumentId],
    queryFn: () => apiFetch<DocumentWithRelations>(`/api/documents/${editDocumentId}`),
    enabled: !!editDocumentId,
  });

  const { data: companies = [], isLoading: companiesLoading } = useQuery<
    Company[]
  >({
    queryKey: ["companies", "all"],
    queryFn: () => apiFetch<Company[]>("/api/companies?type=all"),
  });

  const { data: catalogItems = [] } = useQuery<Item[]>({
    queryKey: ["items"],
    queryFn: () => apiFetch<Item[]>("/api/items"),
  });

  // Populate form when document loads (init pattern with ref to run once)
  const initRef = useRef(false);
  useEffect(() => {
    if (doc && !initRef.current) {
      initRef.current = true;
      // eslint-disable-next-line react-hooks/set-state-in-effect -- intentional one-time form initialization from API data
      void (doc && (setDocumentType(doc.documentType as DocumentType),
      setStatus(doc.status),
      setDate(doc.date.split("T")[0]),
      setLanguage(doc.language as DocumentLanguage),
      setCurrency(doc.currency as Currency),
      setDollarExchangeRate(doc.dollarExchangeRate),
      setHtsusColumnTitle(doc.htsusColumnTitle || ""),
      setShowSterileColumn(doc.showSterileColumn),
      setSenderId(doc.senderId),
      setRecipientId(doc.recipientId || ""),
      setItems(Array.isArray(doc.items) ? doc.items : []),
      setShipmentDetails({ ...emptyShipment, ...doc.shipmentDetails, boxes: Array.isArray(doc.shipmentDetails?.boxes) ? doc.shipmentDetails.boxes : [] }),
      setFinancialDetails({ ...emptyFinancial, ...doc.financialDetails }),
      setNotes(Array.isArray(doc.notes) ? doc.notes : [])));
    }
  }, [doc]);

  const updateMutation = useMutation({
    mutationFn: (body: Record<string, unknown>) =>
      apiFetch(`/api/documents/${editDocumentId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["documents"] });
      queryClient.invalidateQueries({
        queryKey: ["document", editDocumentId],
      });
      toast.success("Document updated successfully");
      navigate("documents");
    },
    onError: () => {
      toast.error("Failed to update document");
    },
  });

  const generatePdfMutation = useMutation({
    mutationFn: () =>
      apiFetch(`/api/documents/${editDocumentId}/pdf`, {
        method: "POST",
      }),
    onSuccess: (data) => {
      if (data?.pdfUrl) {
        toast.success("PDF generated! Opening in new tab...");
        window.open(data.pdfUrl, "_blank");
      } else {
        toast.error("PDF generation returned no URL");
      }
    },
    onError: () => {
      toast.error("Failed to generate PDF");
    },
  });

  const handleSubmit = (newStatus: "draft" | "issued") => {
    if (!senderId) {
      toast.error("Please select a sender company");
      return;
    }

    const totalValue = calculateTotal(items, financialDetails);

    updateMutation.mutate({
      documentType,
      status: newStatus,
      language,
      date,
      senderId,
      recipientId: recipientId || null,
      items,
      dollarExchangeRate,
      currency,
      htsusColumnTitle: htsusColumnTitle || null,
      showSterileColumn,
      shipmentDetails,
      financialDetails: { ...financialDetails, total_value: totalValue },
      notes,
    });
  };

  if (docLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!doc && !docLoading) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => navigate("documents")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Documents
        </Button>
        <p className="text-muted-foreground">Document not found.</p>
      </div>
    );
  }

  const senders = companies.filter((c) => c.type === "sender");
  const recipients = companies.filter((c) => c.type === "recipient");

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("documents")}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold tracking-tight">
                {doc?.number || "Edit Document"}
              </h1>
              <Badge
                variant={status === "issued" ? "default" : "outline"}
              >
                {status === "draft" ? "Draft" : "Issued"}
              </Badge>
            </div>
            <p className="text-muted-foreground text-sm">
              Last updated:{" "}
              {doc?.updatedAt
                ? new Date(doc.updatedAt).toLocaleString()
                : "—"}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          {documentType === "packing_list" && (
            <Button
              variant="outline"
              size="sm"
              className="gap-2"
              onClick={() => toast.info("Sync from invoice - not yet implemented")}
            >
              <RefreshCw className="h-4 w-4" />
              Sync with Invoice
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            className="gap-2"
            onClick={() => generatePdfMutation.mutate()}
            disabled={generatePdfMutation.isPending}
          >
            <FileDown className="h-4 w-4" />
            Generate PDF
          </Button>
        </div>
      </div>

      {/* Header Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Document Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Document Type</Label>
              <Select
                value={documentType}
                onValueChange={(v) => setDocumentType(v as DocumentType)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="proforma">Proforma</SelectItem>
                  <SelectItem value="invoice">Invoice</SelectItem>
                  <SelectItem value="packing_list">Packing List</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Number</Label>
              <Input value={doc?.number || ""} disabled className="bg-muted" />
            </div>
            <div className="space-y-2">
              <Label>Date</Label>
              <Input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select
                value={status}
                onValueChange={setStatus}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="issued">Issued</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Language</Label>
              <Select
                value={language}
                onValueChange={(v) => setLanguage(v as DocumentLanguage)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Spanish</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Currency</Label>
              <Select
                value={currency}
                onValueChange={(v) => setCurrency(v as Currency)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>USD Exchange Rate</Label>
              <Input
                type="number"
                step="0.01"
                placeholder="e.g. 5.25"
                value={dollarExchangeRate ?? ""}
                onChange={(e) =>
                  setDollarExchangeRate(
                    e.target.value ? parseFloat(e.target.value) : null
                  )
                }
              />
            </div>
            <div className="space-y-2">
              <Label>HTSUS Column Title</Label>
              <Input
                placeholder="e.g. HTSUS Code, TARIC"
                value={htsusColumnTitle}
                onChange={(e) => setHtsusColumnTitle(e.target.value)}
              />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Checkbox
              id="showSterile"
              checked={showSterileColumn}
              onCheckedChange={(v) => setShowSterileColumn(!!v)}
            />
            <Label htmlFor="showSterile" className="text-sm">
              Show Sterile Column
            </Label>
          </div>
        </CardContent>
      </Card>

      {/* Companies */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Companies</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Sender *</Label>
              {companiesLoading ? (
                <Skeleton className="h-9 w-full" />
              ) : (
                <Select value={senderId} onValueChange={setSenderId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select sender..." />
                  </SelectTrigger>
                  <SelectContent>
                    {senders.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name} {c.isDefault ? "(Default)" : ""}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
            <div className="space-y-2">
              <Label>Recipient</Label>
              {companiesLoading ? (
                <Skeleton className="h-9 w-full" />
              ) : (
                <Select value={recipientId} onValueChange={setRecipientId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select recipient..." />
                  </SelectTrigger>
                  <SelectContent>
                    {recipients.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name} {c.isDefault ? "(Default)" : ""}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Items */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Items</CardTitle>
        </CardHeader>
        <CardContent>
          <DocumentItemsTable
            items={items}
            onChange={setItems}
            catalogItems={catalogItems}
            language={language}
            showSterileColumn={showSterileColumn}
            htsusColumnTitle={htsusColumnTitle || undefined}
          />
        </CardContent>
      </Card>

      {/* Shipment Details */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Shipment Details</CardTitle>
        </CardHeader>
        <CardContent>
          <ShipmentDetailsForm
            data={shipmentDetails}
            onChange={setShipmentDetails}
          />
        </CardContent>
      </Card>

      {/* Financial Details */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Financial Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Discount (%)</Label>
              <Input
                type="number"
                min={0}
                max={100}
                value={financialDetails.discount}
                onChange={(e) =>
                  setFinancialDetails({
                    ...financialDetails,
                    discount: parseFloat(e.target.value) || 0,
                  })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Shipping Cost</Label>
              <Input
                type="number"
                min={0}
                step="0.01"
                value={financialDetails.shipping_cost}
                onChange={(e) =>
                  setFinancialDetails({
                    ...financialDetails,
                    shipping_cost: parseFloat(e.target.value) || 0,
                  })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Insurance</Label>
              <Input
                type="number"
                min={0}
                step="0.01"
                value={financialDetails.insurance}
                onChange={(e) =>
                  setFinancialDetails({
                    ...financialDetails,
                    insurance: parseFloat(e.target.value) || 0,
                  })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Bank Fees</Label>
              <Input
                type="number"
                min={0}
                step="0.01"
                value={financialDetails.bank_fees}
                onChange={(e) =>
                  setFinancialDetails({
                    ...financialDetails,
                    bank_fees: parseFloat(e.target.value) || 0,
                  })
                }
              />
            </div>
          </div>
          <Separator />
          <div className="flex justify-end">
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Total Value</p>
              <p className="text-2xl font-bold">
                {currency}{" "}
                {calculateTotal(items, financialDetails).toFixed(2)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Notes */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Notes</CardTitle>
        </CardHeader>
        <CardContent>
          <NotesForm notes={notes} onChange={setNotes} />
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-3 justify-end pb-6">
        <Button variant="outline" onClick={() => navigate("documents")}>
          Cancel
        </Button>
        <Button
          variant="outline"
          onClick={() => handleSubmit("draft")}
          disabled={updateMutation.isPending}
          className="gap-2"
        >
          <Save className="h-4 w-4" />
          Save as Draft
        </Button>
        <Button
          onClick={() => handleSubmit("issued")}
          disabled={updateMutation.isPending}
          className="gap-2"
        >
          <Send className="h-4 w-4" />
          Issue Document
        </Button>
      </div>
    </div>
  );
}