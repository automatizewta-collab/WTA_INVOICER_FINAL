"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { useAppStore } from "@/lib/store";
import type {
  DocumentType,
  DocumentLanguage,
  Currency,
  DocumentItem,
  ShipmentDetails,
  FinancialDetails,
  Company,
  Item,
} from "@/lib/types";
import { DocumentItemsTable } from "@/components/shared/DocumentItemsTable";
import { ShipmentDetailsForm } from "@/components/shared/ShipmentDetailsForm";
import { NotesForm } from "@/components/shared/NotesForm";
import { apiFetch } from "@/lib/utils";
import { ArrowLeft, Save, Send, Database } from "lucide-react";
import { ErpImportDialog } from "@/components/shared/ErpImportDialog";

const emptyShipment: ShipmentDetails = {
  carrier: "",
  incoterms: "",
  origin_port: "",
  destination_port: "",
  shipment_date: "",
  awb: "",
  boxes: [],
  gross_weight: 0,
  net_weight: 0,
};

const emptyFinancial: FinancialDetails = {
  discount: 0,
  shipping_cost: 0,
  insurance: 0,
  bank_fees: 0,
  total_value: 0,
};

function calculateTotal(items: DocumentItem[], financial: FinancialDetails): number {
  const subtotal = items.reduce((sum, item) => {
    return sum + item.quantity * item.unit_price * (1 - item.discount / 100);
  }, 0);
  return subtotal * (1 - (financial.discount || 0) / 100) + (financial.shipping_cost || 0) + (financial.insurance || 0) + (financial.bank_fees || 0);
}

export function NewDocumentView() {
  const navigate = useAppStore((s) => s.navigate);
  const queryClient = useQueryClient();

  const [documentType, setDocumentType] = useState<DocumentType>("proforma");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [language, setLanguage] = useState<DocumentLanguage>("en");
  const [currency, setCurrency] = useState<Currency>("USD");
  const [dollarExchangeRate, setDollarExchangeRate] = useState<number | null>(null);
  const [htsusColumnTitle, setHtsusColumnTitle] = useState("");
  const [showSterileColumn, setShowSterileColumn] = useState(false);
  const [senderId, setSenderId] = useState("");
  const [recipientId, setRecipientId] = useState("");
  const [items, setItems] = useState<DocumentItem[]>([]);
  const [shipmentDetails, setShipmentDetails] = useState<ShipmentDetails>(emptyShipment);
  const [financialDetails, setFinancialDetails] = useState<FinancialDetails>(emptyFinancial);
  const [notes, setNotes] = useState<string[]>([]);
  const [contactName, setContactName] = useState("");
  const [contactPhone, setContactPhone] = useState("");
  const [orderNumber, setOrderNumber] = useState("");
  const [erpDialogOpen, setErpDialogOpen] = useState(false);

  const { data: companies = [], isLoading: companiesLoading } = useQuery<Company[]>({
    queryKey: ["companies", "all"],
    queryFn: () => apiFetch<Company[]>("/api/companies?type=all"),
  });

  const senders = companies.filter((c) => c.type === "sender");
  const recipients = companies.filter((c) => c.type === "recipient");

  const { data: catalogItems = [], isLoading: catalogLoading } = useQuery<Item[]>({
    queryKey: ["items"],
    queryFn: () => apiFetch<Item[]>("/api/items"),
  });

  const createMutation = useMutation({
    mutationFn: (body: Record<string, unknown>) =>
      apiFetch("/api/documents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["documents"] });
      toast.success("Document created successfully");
      navigate("documents");
    },
    onError: () => {
      toast.error("Failed to create document");
    },
  });

  const handleSubmit = (status: "draft" | "issued") => {
    if (!senderId) {
      toast.error("Please select a sender company");
      return;
    }
    if (items.length === 0) {
      toast.error("Please add at least one item");
      return;
    }

    const totalValue = calculateTotal(items, financialDetails);

    createMutation.mutate({
      documentType,
      status,
      language,
      date,
      senderId,
      recipientId: recipientId || null,
      items,
      dollarExchangeRate,
      currency,
      htsusColumnTitle: htsusColumnTitle || null,
      showSterileColumn,
      shipmentDetails,
      financialDetails: { ...financialDetails, total_value: totalValue },
      notes,
      contactName: contactName || null,
      contactPhone: contactPhone || null,
      orderNumber: orderNumber || null,
      customNumber: orderNumber || undefined,
    });
  };

  // ── ERP Import handler ──
  const handleErpImported = async (data: {
    orderNumber: number;
    client: { name: string; cnpj: string; email: string; address: string; city: string; state: string; postalCode: string; country: string };
    items: Array<{ erpCode: string; matched: boolean; quantity: number; unit_price: number; gross_weight: number; net_weight: number; htsus_code: string; sterile_at_import: "YES" | "NO"; name_en: string; name_es: string; end_use: string }>;
  }) => {
    // Set OV number
    setOrderNumber(String(data.orderNumber));

    // Find or create recipient company
    let companyId = recipients.find((c) =>
      c.cnpj && c.cnpj.replace(/\D/g, "") === data.client.cnpj.replace(/\D/g, "")
    )?.id;

    if (!companyId) {
      // Try by name
      companyId = recipients.find((c) =>
        c.name.toLowerCase() === data.client.name.toLowerCase()
      )?.id;
    }

    if (!companyId) {
      // Create new recipient company
      try {
        const created = await apiFetch<{ id: string }>("/api/companies", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: data.client.name,
            type: "recipient",
            cnpj: data.client.cnpj,
            email: data.client.email,
            address: data.client.address,
            city: data.client.city,
            state: data.client.state,
            postalCode: data.client.postalCode,
            country: data.client.country,
          }),
        });
        companyId = created.id;
        queryClient.invalidateQueries({ queryKey: ["companies"] });
        toast.success(`Empresa "${data.client.name}" criada automaticamente`);
      } catch (err) {
        toast.error("Erro ao criar empresa destinatária");
        console.error(err);
        return;
      }
    }

    setRecipientId(companyId);

    // Fill items from ERP
    const docItems: DocumentItem[] = data.items.map((item, idx) => ({
      item_id: item.erpCode,
      quantity: item.quantity,
      unit_price: item.unit_price,
      discount: 0,
      line_number: idx + 1,
      gross_weight: item.gross_weight,
      net_weight: item.net_weight,
      htsus_code: item.htsus_code,
      sterile_at_import: item.sterile_at_import,
    }));
    setItems(docItems);

    const unmatched = data.items.filter((i) => !i.matched).length;
    if (unmatched > 0) {
      toast.warning(`${unmatched} item(s) não encontrado(s) no catálogo. Ajuste o preço manualmente.`, { duration: 6000 });
    } else {
      toast.success(`OV ${data.orderNumber} importada: ${data.items.length} itens`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate("documents")}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">New Document</h1>
          <p className="text-muted-foreground">
            Create a new commercial document
          </p>
        </div>
      </div>

      {/* ERP Import Section */}
      <Card className="border-dashed border-2 border-primary/30 bg-primary/5">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Database className="h-4 w-4" />
            Importar do ERP
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-3 items-end">
            <div className="flex-1 space-y-2">
              <Label>Sender *</Label>
              {companiesLoading ? (
                <Skeleton className="h-9 w-full" />
              ) : (
                <Select value={senderId} onValueChange={setSenderId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o remetente..." />
                  </SelectTrigger>
                  <SelectContent>
                    {senders.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name} {c.isDefault ? "(Default)" : ""}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
            <div className="flex-1 space-y-2">
              <Label>Nº OV</Label>
              <Input
                type="number"
                min={1}
                placeholder="Ex: 101495"
                value={orderNumber}
                onChange={(e) => setOrderNumber(e.target.value)}
                disabled
                className="bg-muted"
              />
            </div>
            <Button
              onClick={() => setErpDialogOpen(true)}
              disabled={!senderId}
              className="gap-2"
            >
              <Database className="h-4 w-4" />
              Importar
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
            <div className="space-y-2">
              <Label>Nome do Contato</Label>
              <Input
                placeholder="Nome do contato no destinatário"
                value={contactName}
                onChange={(e) => setContactName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Telefone do Contato</Label>
              <Input
                placeholder="+55 11 99999-9999"
                value={contactPhone}
                onChange={(e) => setContactPhone(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <ErpImportDialog
        open={erpDialogOpen}
        onOpenChange={setErpDialogOpen}
        onImported={handleErpImported}
      />

      {/* Header Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Document Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Document Type</Label>
              <Select
                value={documentType}
                onValueChange={(v) => setDocumentType(v as DocumentType)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="proforma">Proforma</SelectItem>
                  <SelectItem value="invoice">Invoice</SelectItem>
                  <SelectItem value="packing_list">Packing List</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Date</Label>
              <Input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Language</Label>
              <Select
                value={language}
                onValueChange={(v) => setLanguage(v as DocumentLanguage)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Spanish</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Currency</Label>
              <Select
                value={currency}
                onValueChange={(v) => setCurrency(v as Currency)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>USD Exchange Rate</Label>
              <Input
                type="number"
                step="0.01"
                placeholder="e.g. 5.25"
                value={dollarExchangeRate ?? ""}
                onChange={(e) =>
                  setDollarExchangeRate(
                    e.target.value ? parseFloat(e.target.value) : null
                  )
                }
              />
            </div>
            <div className="space-y-2">
              <Label>HTSUS Column Title</Label>
              <Input
                placeholder="e.g. HTSUS Code, TARIC"
                value={htsusColumnTitle}
                onChange={(e) => setHtsusColumnTitle(e.target.value)}
              />
            </div>
            <div className="flex items-end gap-2 pb-1">
              <Checkbox
                id="showSterile"
                checked={showSterileColumn}
                onCheckedChange={(v) => setShowSterileColumn(!!v)}
              />
              <Label htmlFor="showSterile" className="text-sm">
                Show Sterile Column
              </Label>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Companies */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Recipient</CardTitle>
        </CardHeader>
        <CardContent>
          {companiesLoading ? (
            <Skeleton className="h-9 w-full" />
          ) : (
            <Select value={recipientId} onValueChange={setRecipientId}>
              <SelectTrigger>
                <SelectValue placeholder="Select recipient..." />
              </SelectTrigger>
              <SelectContent>
                {recipients.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name} {c.isDefault ? "(Default)" : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </CardContent>
      </Card>

      {/* Items */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Items</CardTitle>
        </CardHeader>
        <CardContent>
          {catalogLoading ? (
            <Skeleton className="h-40 w-full" />
          ) : (
            <DocumentItemsTable
              items={items}
              onChange={setItems}
              catalogItems={catalogItems}
              language={language}
              showSterileColumn={showSterileColumn}
              htsusColumnTitle={htsusColumnTitle || undefined}
            />
          )}
        </CardContent>
      </Card>

      {/* Shipment Details */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Shipment Details</CardTitle>
        </CardHeader>
        <CardContent>
          <ShipmentDetailsForm
            data={shipmentDetails}
            onChange={setShipmentDetails}
          />
        </CardContent>
      </Card>

      {/* Financial Details */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Financial Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Discount (%)</Label>
              <Input
                type="number"
                min={0}
                max={100}
                value={financialDetails.discount}
                onChange={(e) =>
                  setFinancialDetails({
                    ...financialDetails,
                    discount: parseFloat(e.target.value) || 0,
                  })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Shipping Cost</Label>
              <Input
                type="number"
                min={0}
                step="0.01"
                value={financialDetails.shipping_cost}
                onChange={(e) =>
                  setFinancialDetails({
                    ...financialDetails,
                    shipping_cost: parseFloat(e.target.value) || 0,
                  })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Insurance</Label>
              <Input
                type="number"
                min={0}
                step="0.01"
                value={financialDetails.insurance}
                onChange={(e) =>
                  setFinancialDetails({
                    ...financialDetails,
                    insurance: parseFloat(e.target.value) || 0,
                  })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Bank Fees</Label>
              <Input
                type="number"
                min={0}
                step="0.01"
                value={financialDetails.bank_fees}
                onChange={(e) =>
                  setFinancialDetails({
                    ...financialDetails,
                    bank_fees: parseFloat(e.target.value) || 0,
                  })
                }
              />
            </div>
          </div>
          <Separator />
          <div className="flex justify-end">
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Total Value</p>
              <p className="text-2xl font-bold">
                {currency}{" "}
                {calculateTotal(items, financialDetails).toFixed(2)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Notes */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Notes</CardTitle>
        </CardHeader>
        <CardContent>
          <NotesForm notes={notes} onChange={setNotes} />
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-3 justify-end pb-6">
        <Button
          variant="outline"
          onClick={() => navigate("documents")}
        >
          Cancel
        </Button>
        <Button
          variant="outline"
          onClick={() => handleSubmit("draft")}
          disabled={createMutation.isPending}
          className="gap-2"
        >
          <Save className="h-4 w-4" />
          Save as Draft
        </Button>
        <Button
          onClick={() => handleSubmit("issued")}
          disabled={createMutation.isPending}
          className="gap-2"
        >
          <Send className="h-4 w-4" />
          Issue Document
        </Button>
      </div>
    </div>
  );
}