// ============================================
// INVOICER - Database Seed Script
// Usage: bun db:seed
// Idempotent: seeds companies and items independently
// ============================================

import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function seedCompanies() {
  const count = await prisma.company.count();
  if (count > 0) {
    console.log(`[SEED] Companies: ${count} already exist, skipping.`);
    return;
  }

  console.log("[SEED] Creating companies...");

  const sender = await prisma.company.create({
    data: {
      name: "Brazil Export Corp.",
      type: "sender",
      contactName: "Carlos Silva",
      address: "Av. Paulista, 1000",
      city: "São Paulo",
      postalCode: "01310-100",
      state: "SP",
      country: "Brazil",
      email: "export@brazilexport.com",
      phone: "+55 11 3000-0001",
      cnpj: "12.345.678/0001-90",
      stateRegistration: "123.456.789.000",
      isDefault: true,
      bankDetails: "Bank: Banco do Brasil | SWIFT: BRASBRRJ | Account: 12345-6 | Ag: 0001",
      midCode: "BR-MID-001",
    },
  });
  console.log(`[SEED]   Sender created: ${sender.name} (ID: ${sender.id})`);

  const recipient = await prisma.company.create({
    data: {
      name: "Global Medical Imports Inc.",
      type: "recipient",
      contactName: "John Smith",
      address: "123 Medical Drive, Suite 400",
      city: "Miami",
      postalCode: "33101",
      state: "FL",
      country: "United States",
      email: "purchasing@globalmedical.com",
      phone: "+1 305-555-0100",
    },
  });
  console.log(`[SEED]   Recipient created: ${recipient.name} (ID: ${recipient.id})`);
}

async function seedItems() {
  const count = await prisma.item.count();
  if (count > 0) {
    console.log(`[SEED] Items: ${count} already exist, skipping.`);
    return;
  }

  console.log("[SEED] Creating items...");

  const itemData = [
    {
      code: "SG-001",
      namePt: "Luva Cirúrgica Estéril (par)",
      nameEn: "Surgical Sterile Glove (pair)",
      nameEs: "Guante Quirúrgico Estéril (par)",
      unitValueUsd: 0.85,
      grossWeight: 0.06,
      netWeight: 0.05,
      htsusCode: "4015.19.0540",
      endUse: "Surgical examination gloves for medical procedures",
      endUseEs: "Guantes de examen quirúrgico para procedimientos médicos",
      sterileAtImport: "YES",
    },
    {
      code: "SY-001",
      namePt: "Seringa Descartável 5ml",
      nameEn: "Disposable Syringe 5ml",
      nameEs: "Jeringa Desechable 5ml",
      unitValueUsd: 0.12,
      grossWeight: 0.015,
      netWeight: 0.012,
      htsusCode: "9013.31.0040",
      endUse: "Medical disposable syringe for injections",
      endUseEs: "Jeringa desechable médica para inyecciones",
      sterileAtImport: "YES",
    },
    {
      code: "MS-001",
      namePt: "Máscara Cirúrgica Descartável",
      nameEn: "Disposable Surgical Mask",
      nameEs: "Mascarilla Quirúrgica Desechable",
      unitValueUsd: 0.25,
      grossWeight: 0.01,
      netWeight: 0.008,
      htsusCode: "6307.90.9880",
      endUse: "Surgical face mask for medical environments",
      endUseEs: "Mascarilla facial quirúrgica para entornos médicos",
      sterileAtImport: "NO",
    },
  ];

  for (const item of itemData) {
    const created = await prisma.item.create({ data: item });
    console.log(`[SEED]   Item created: ${created.code} - ${created.nameEn}`);
  }
}

async function main() {
  console.log("[SEED] ========================================");
  console.log("[SEED] Starting database seed...");
  console.log("[SEED] ========================================");

  // Seed companies and items independently
  await seedCompanies();
  await seedItems();

  // Summary
  const companyCount = await prisma.company.count();
  const itemCount = await prisma.item.count();
  console.log("\n[SEED] ========================================");
  console.log(`[SEED] Done. Database now has ${companyCount} companies and ${itemCount} items.`);
  console.log("[SEED] ========================================");
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error("[SEED] FATAL ERROR:", e);
    await prisma.$disconnect();
    process.exit(1);
  });